const express = require("express");
const mongoose = require("mongoose");
const Course = require("./models/courseModel");

const app = express();

app.use(express.json());

mongoose
  .connect("mongodb://127.0.0.1:27017/smartLMS")
  .then(() => {
    console.log("MongoDB connected");
  })
  .catch((error) => {
    console.log("MongoDB connection error:", error);
  });

app.get("/", (req, res) => {
  res.json({
    message: "Smart LMS API is running"
  });
});

app.post("/courses", async (req, res) => {
  try {
    const course = await Course.create(req.body);

    res.status(201).json({
      status: "success",
      data: {
        course: course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: error.message
    });
  }
});

app.get("/courses", async (req, res) => {
  try {
    const courses = await Course.find();

    res.status(200).json({
      status: "success",
      results: courses.length,
      data: {
        courses: courses
      }
    });
  } catch (error) {
    res.status(500).json({
      status: "fail",
      message: error.message
    });
  }
});

app.get("/courses/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        course: course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: "Invalid course ID"
    });
  }
});

app.patch("/courses/:id", async (req, res) => {
  try {
    const course = await Course.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        course: course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: error.message
    });
  }
});

app.delete("/courses/:id", async (req, res) => {
  try {
    const course = await Course.findByIdAndDelete(req.params.id);

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      message: "Course deleted successfully"
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: "Invalid course ID"
    });
  }
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});