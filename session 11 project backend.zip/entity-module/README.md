# Smart LMS - Course Entity Module

## Project Description

Smart LMS is a Learning Management System that helps students access and manage educational courses.

This module focuses on managing courses using Node.js, Express.js, MongoDB, and Mongoose.

## Entity

The entity selected for this module is **Course** because courses are one of the main resources in the Smart LMS project.

Each course contains:

- Title
- Description
- Instructor
- Category
- Price
- Level

## Technologies Used

- Node.js
- Express.js
- MongoDB
- Mongoose
- Postman

## CRUD Routes

| Method | Route | Description |
|---|---|---|
| POST | `/courses` | Create a new course |
| GET | `/courses` | Get all courses |
| GET | `/courses/:id` | Get a course by ID |
| PATCH | `/courses/:id` | Update a course |
| DELETE | `/courses/:id` | Delete a course |

## How to Run the Project

### 1. Install dependencies

```bash
npm install