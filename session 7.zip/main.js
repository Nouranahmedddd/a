const addGrade = require("./modules/add.grade");
const readGrades = require("./modules/read.grades");
const updateGrade = require("./modules/update.grade");
const deleteGrade = require("./modules/delete.grade");

addGrade(1, "Ali", "Math", 95);
addGrade(2, "Sara", "English", 80);
addGrade(3, "Omar", "Science", 70);

console.log("All Grades");
readGrades();

updateGrade(2, 90);

console.log("After Update");
readGrades();

deleteGrade(3);

console.log("After Delete");
readGrades();