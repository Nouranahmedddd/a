function calculateAverage(grades) {
    let total = 0;

    for (let grade of grades) {
        total += grade;
    }

    return total / grades.length;
}

module.exports = calculateAverage;