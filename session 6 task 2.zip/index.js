const express = require("express");

const addStudent = require("./modules/addStudent");
const listStudents = require("./modules/listStudents");
const filterPassed = require("./modules/filterPassed");

const app = express();

addStudent("Ali", [80, 90, 70]);
addStudent("Sara", [50, 60, 55]);
addStudent("Omar", [90, 95, 100]);

console.log("All Students:");
listStudents();

console.log("----------------");

filterPassed();

app.get("/", (req, res) => {
    res.send("Student Gradebook is Working");
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});