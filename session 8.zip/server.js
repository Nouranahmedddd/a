const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const filePath = path.join(__dirname, "books.json");

function readBooks(callback) {
  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) {
      callback(err, null);
      return;
    }

    try {
      const books = data ? JSON.parse(data) : [];
      callback(null, books);
    } catch (error) {
      callback(error, null);
    }
  });
}

function writeBooks(books, callback) {
  fs.writeFile(filePath, JSON.stringify(books, null, 2), (err) => {
    callback(err);
  });
}

const server = http.createServer((req, res) => {
  res.setHeader("Content-Type", "application/json");

  // GET /books
  if (req.method === "GET" && req.url === "/books") {
    readBooks((err, books) => {
      if (err) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: "Error reading file" }));
        return;
      }

      res.writeHead(200);
      res.end(JSON.stringify(books));
    });
  }

  // POST /books
  else if (req.method === "POST" && req.url === "/books") {
    let body = "";

    req.on("data", (chunk) => {
      body += chunk;
    });

    req.on("end", () => {
      let newBook;

      try {
        newBook = JSON.parse(body);
      } catch {
        res.writeHead(400);
        res.end(JSON.stringify({ error: "Invalid JSON" }));
        return;
      }

      readBooks((err, books) => {
        if (err) {
          res.writeHead(500);
          res.end(JSON.stringify({ error: "Error reading file" }));
          return;
        }

        const newId =
          books.length > 0
            ? Math.max(...books.map((book) => book.id)) + 1
            : 1;

        const book = {
          id: newId,
          title: newBook.title,
          author: newBook.author,
          price: newBook.price,
          available: newBook.available,
        };

        books.push(book);

        writeBooks(books, (err) => {
          if (err) {
            res.writeHead(500);
            res.end(JSON.stringify({ error: "Error writing file" }));
            return;
          }

          res.writeHead(201);
          res.end(JSON.stringify(book));
        });
      });
    });
  }

  // DELETE /books/:id
  else if (req.method === "DELETE" && req.url.startsWith("/books/")) {
    const id = parseInt(req.url.split("/")[2]);

    readBooks((err, books) => {
      if (err) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: "Error reading file" }));
        return;
      }

      const index = books.findIndex((book) => book.id === id);

      if (index === -1) {
        res.writeHead(404);
        res.end(JSON.stringify({ error: "Book not found" }));
        return;
      }

      const deletedBook = books.splice(index, 1)[0];

      writeBooks(books, (err) => {
        if (err) {
          res.writeHead(500);
          res.end(JSON.stringify({ error: "Error writing file" }));
          return;
        }

        res.writeHead(200);
        res.end(
          JSON.stringify({
            message: "Book deleted successfully",
            book: deletedBook,
          })
        );
      });
    });
  }

  // Invalid Route
  else {
    res.writeHead(404);
    res.end(JSON.stringify({ error: "Route not found" }));
  }
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});