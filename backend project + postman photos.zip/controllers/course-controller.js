const Course = require("../models/courseModel");

exports.createCourse = async (req, res) => {
  try {
    const courseData = {
      title: req.body.title,
      description: req.body.description,
      instructor: req.body.instructor,
      category: req.body.category,
      price: req.body.price,
      level: req.body.level
    };

    if (req.file) {
      courseData.image = req.file.path;
    }

    const course = await Course.create(courseData);

    res.status(201).json({
      status: "success",
      data: {
        course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: error.message
    });
  }
};

exports.getAllCourses = async (req, res) => {
  try {
    const courses = await Course.find();

    res.status(200).json({
      status: "success",
      results: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    res.status(500).json({
      status: "fail",
      message: error.message
    });
  }
};

exports.getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: "Invalid course ID"
    });
  }
};

exports.updateCourse = async (req, res) => {
  try {
    const updateData = {
      title: req.body.title,
      description: req.body.description,
      instructor: req.body.instructor,
      category: req.body.category,
      price: req.body.price,
      level: req.body.level
    };

    if (req.file) {
      updateData.image = req.file.path;
    }

    const course = await Course.findByIdAndUpdate(
      req.params.id,
      updateData,
      {
        new: true,
        runValidators: true
      }
    );

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        course
      }
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: error.message
    });
  }
};

exports.deleteCourse = async (req, res) => {
  try {
    const course = await Course.findByIdAndDelete(req.params.id);

    if (!course) {
      return res.status(404).json({
        status: "fail",
        message: "Course not found"
      });
    }

    res.status(200).json({
      status: "success",
      message: "Course deleted successfully"
    });
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: "Invalid course ID"
    });
  }
};