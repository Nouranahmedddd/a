const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const courseRouter = require("./routes/course-router");

const app = express();

app.use(express.json());

app.use("/uploads", express.static("uploads"));

console.log("courseRouter type:", typeof courseRouter);

app.use("/courses", courseRouter);

mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/smartLMS")
  .then(() => {
    console.log("MongoDB connected");
  })
  .catch((error) => {
    console.log("MongoDB connection error:", error.message);
  });

app.get("/", (req, res) => {
  res.json({
    message: "Smart LMS API is running"
  });
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});