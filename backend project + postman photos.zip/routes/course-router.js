const express = require("express");

const router = express.Router();

const courseController = require("../controllers/course-controller");
const upload = require("../middleware/upload");

router.post("/", upload.single("image"), courseController.createCourse);

router.get("/", courseController.getAllCourses);

router.get("/:id", courseController.getCourseById);

router.patch("/:id", upload.single("image"), courseController.updateCourse);

router.delete("/:id", courseController.deleteCourse);

module.exports = router;