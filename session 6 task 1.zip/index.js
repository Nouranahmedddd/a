const express = require("express");

const addToCart = require("./modules/addToCart");
const removeFromCart = require("./modules/removeFromCart");
const listCart = require("./modules/listCart");
const calculateTotal = require("./modules/calculateTotal");

const app = express();

addToCart(1);
addToCart(2);

listCart();

calculateTotal();

removeFromCart(1);

listCart();

calculateTotal();

app.get("/", (req, res) => {
    res.send("Shopping Cart is Working");
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});