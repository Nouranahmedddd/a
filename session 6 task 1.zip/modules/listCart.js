const cart = require("../data/cart");

function listCart() {
    console.log(cart);
}

module.exports = listCart;