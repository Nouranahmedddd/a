const products = require("../data/products");
const cart = require("../data/cart");

function addToCart(id) {
    const product = products.find(p => p.id === id);

    if (product) {
        cart.push(product);
        console.log(product.name + " added.");
    } else {
        console.log("Product not found.");
    }
}

module.exports = addToCart;