const cart = require("../data/cart");

function removeFromCart(id) {
    const index = cart.findIndex(item => item.id === id);

    if (index !== -1) {
        cart.splice(index, 1);
        console.log("Removed.");
    } else {
        console.log("Product not found.");
    }
}

module.exports = removeFromCart;